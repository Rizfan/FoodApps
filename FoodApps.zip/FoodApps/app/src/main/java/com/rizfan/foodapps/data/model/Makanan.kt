package com.rizfan.foodapps.data.model

data class Makanan(
    val id: Int = 0,
    val nama: String = "",
    val harga: Int = 0,
    val gambarUrl: String = "",
    val deskripsi: String = ""
)
