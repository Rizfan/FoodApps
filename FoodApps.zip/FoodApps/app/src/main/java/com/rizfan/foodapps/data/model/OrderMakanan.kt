package com.rizfan.foodapps.data.model

data class OrderMakanan(
    val makanan: Makanan,
    val count: Int
)